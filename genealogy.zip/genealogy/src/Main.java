import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) throws NegativeLifespanException {
//        PlantUMLRunner.generate("test",
//                "C:\\Users\\mkurzyna\\OneDrive - Softsystem Directory\\Desktop",
//                "family.puml");

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        try {
            Person p = new Person("Jan",
                    "Kowalski", LocalDate.parse("12-12-1978", formatter));
            System.out.println(p.toUML());
            Person p2 = new Person("Jan",
                    "Nowak", LocalDate.parse("12-12-1977", formatter));
            System.out.println(p.toUML());
        } catch (NegativeLifespanException e) {
            throw new RuntimeException(e);
        }

    }
}