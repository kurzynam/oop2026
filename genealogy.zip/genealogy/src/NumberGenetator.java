public final class NumberGenetator {
    private static NumberGenetator instance;
    int number = 0;

    public static NumberGenetator getInstance(){
        if(instance == null){
            instance = new NumberGenetator();
        }
        return instance;
    }
    public void increment(){
        number++;
    }
    public int getNumber(){
        return number;
    }
}
