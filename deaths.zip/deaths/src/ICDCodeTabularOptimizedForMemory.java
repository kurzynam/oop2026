//zad4
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class ICDCodeTabularOptimizedForMemory
        implements ICDCodeTabular {

    private String path;

    public ICDCodeTabularOptimizedForMemory(String path) {
        this.path = path;
    }

    @Override
    public String getDescription(String code)
            throws IndexOutOfBoundsException {

        try {

            BufferedReader br =
                    new BufferedReader(new FileReader(path));

            String line;

            int lineNumber = 0;

            while ((line = br.readLine()) != null) {

                lineNumber++;

                if (lineNumber < 88) {
                    continue;
                }

                line = line.trim();

                if (line.matches("^[A-Z][0-9]{2}.*")) {

                    String[] parts = line.split("\\s+", 2);

                    if (parts.length == 2) {

                        String fileCode = parts[0];
                        String desc = parts[1];

                        if (fileCode.equals(code)) {

                            br.close();

                            return desc;
                        }
                    }
                }
            }

            br.close();

        } catch (IOException e) {
            e.printStackTrace();
        }

        throw new IndexOutOfBoundsException(
                "Nie znaleziono kodu: " + code);
    }
}