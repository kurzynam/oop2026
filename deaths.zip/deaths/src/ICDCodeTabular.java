//zad4
public interface ICDCodeTabular {

    String getDescription(String code)
            throws IndexOutOfBoundsException;
}