//zad1
public class DeathCauseStatistic {

    private String icd10Code;
    private int[] deaths;

    private static final int[][] AGE_BRACKETS = {
            {0, 4},
            {5, 9},
            {10, 14},
            {15, 19},
            {20, 24},
            {25, 29},
            {30, 34},
            {35, 39},
            {40, 44},
            {45, 49},
            {50, 54},
            {55, 59},
            {60, 64},
            {65, 69},
            {70, 74},
            {75, 79},
            {80, 84},
            {85, Integer.MAX_VALUE}
    };

    public DeathCauseStatistic(String icd10Code, int[] deaths) {
        this.icd10Code = icd10Code;
        this.deaths = deaths;
    }

    public static DeathCauseStatistic fromCsvLine(String line) {

        String[] data = line.split(";|,");

        String code = data[0].replace("\t", "").trim();

        if (!code.matches("[A-Z][0-9]{2}.*")) {
            throw new IllegalArgumentException("Niepoprawny kod ICD-10");
        }

        int[] deaths = new int[data.length - 2];

        for (int i = 2; i < data.length; i++) {

            String value = data[i].trim();

            if (value.isEmpty()) {
                deaths[i - 2] = 0;
            } else {
                deaths[i - 2] = Integer.parseInt(value);
            }
        }

        return new DeathCauseStatistic(code, deaths);
    }

    public String getIcd10Code() {
        return icd10Code;
    }

    public int getDeathsForAge(int age) {

        AgeBracketDeaths abd = getAgeBracketDeaths(age);

        return abd.deathCount;
    }

    //zad2

    public class AgeBracketDeaths {

        public final int young;
        public final int old;
        public final int deathCount;

        public AgeBracketDeaths(int young, int old, int deathCount) {
            this.young = young;
            this.old = old;
            this.deathCount = deathCount;
        }

        @Override
        public String toString() {
            return young + "-" + old + " : " + deathCount;
        }
    }

    public AgeBracketDeaths getAgeBracketDeaths(int age) {

        for (int i = 0; i < AGE_BRACKETS.length; i++) {

            int young = AGE_BRACKETS[i][0];
            int old = AGE_BRACKETS[i][1];

            if (age >= young && age <= old) {

                int deathCount = 0;

                if (i < deaths.length) {
                    deathCount = deaths[i];
                }

                return new AgeBracketDeaths(young, old, deathCount);
            }
        }

        return null;
    }
}