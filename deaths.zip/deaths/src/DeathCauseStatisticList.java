//zad3
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class DeathCauseStatisticList {

    private List<DeathCauseStatistic> statistics;

    public DeathCauseStatisticList() {
        statistics = new ArrayList<>();
    }

    public void repopulate(String path) throws IOException {

        statistics.clear();

        BufferedReader br = new BufferedReader(new FileReader(path));

        String line;

        br.readLine();

        while ((line = br.readLine()) != null) {

            if (line.trim().isEmpty()) {
                continue;
            }

            try {
                DeathCauseStatistic stat =
                        DeathCauseStatistic.fromCsvLine(line);

                statistics.add(stat);

            } catch (Exception e) {
            }
        }

        br.close();
    }

    public List<DeathCauseStatistic> mostDeadlyDiseases(int age, int n) {

        List<DeathCauseStatistic> result =
                new ArrayList<>(statistics);

        result.sort(new Comparator<DeathCauseStatistic>() {
            @Override
            public int compare(DeathCauseStatistic o1,
                               DeathCauseStatistic o2) {

                int d1 = o1.getDeathsForAge(age);
                int d2 = o2.getDeathsForAge(age);

                return Integer.compare(d2, d1);
            }
        });

        if (n > result.size()) {
            n = result.size();
        }

        return result.subList(0, n);
    }
}