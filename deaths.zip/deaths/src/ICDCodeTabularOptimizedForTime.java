//zad4
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class ICDCodeTabularOptimizedForTime
        implements ICDCodeTabular {

    private Map<String, String> descriptions;

    public ICDCodeTabularOptimizedForTime(String path)
            throws IOException {

        descriptions = new HashMap<>();

        loadFile(path);
    }

    private void loadFile(String path)
            throws IOException {

        BufferedReader br =
                new BufferedReader(new FileReader(path));

        String line;

        int lineNumber = 0;

        while ((line = br.readLine()) != null) {

            lineNumber++;

            if (lineNumber < 88) {
                continue;
            }

            line = line.trim();

            if (line.matches("^[A-Z][0-9]{2}.*")) {

                String[] parts = line.split("\\s+", 2);

                if (parts.length == 2) {

                    String code = parts[0];
                    String desc = parts[1];

                    descriptions.put(code, desc);
                }
            }
        }

        br.close();
    }

    @Override
    public String getDescription(String code)
            throws IndexOutOfBoundsException {

        String result = descriptions.get(code);

        if (result == null) {
            throw new IndexOutOfBoundsException(
                    "Nie znaleziono kodu: " + code);
        }

        return result;
    }
}